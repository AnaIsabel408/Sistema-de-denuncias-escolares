
<?php
session_start();


if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../../cadastros/login.html');
    exit;
}


if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header('Location: ../usuarios/index.php');
    exit;
}

?>