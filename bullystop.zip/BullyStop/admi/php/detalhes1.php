<?php

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}

require_once '../../php/conexao.php';

try {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id <= 0) {
        throw new Exception('ID inválido');
    }


    $sqlInst = "SELECT id, nome, endereco, telefone FROM instituicoes WHERE id = ?";
    $stmt = $conn->prepare($sqlInst);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultInst = $stmt->get_result();
    
    if ($resultInst->num_rows === 0) {
        throw new Exception('Instituição não encontrada');
    }
    
    $inst = $resultInst->fetch_assoc();
    $stmt->close();


    $sqlUsuarios = "SELECT id, nome, email, tipo_usuario, codigo_escolar, idade, data_cadastro 
                    FROM usuarios 
                    WHERE instituicao_id = ? 
                    ORDER BY nome ASC";
    $stmt = $conn->prepare($sqlUsuarios);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultUsuarios = $stmt->get_result();
    
    $usuarios = [];
    while ($row = $resultUsuarios->fetch_assoc()) {
        $usuarios[] = [
            'id' => $row['id'],
            'nome' => $row['nome'],
            'email' => $row['email'],
            'tipo_usuario' => $row['tipo_usuario'],
            'codigo_escolar' => $row['codigo_escolar'],
            'idade' => $row['idade'],
            'data_cadastro' => $row['data_cadastro']
        ];
    }
    $stmt->close();

    echo json_encode([
        'success' => true,
        'instituicao' => [
            'id' => $inst['id'],
            'nome' => $inst['nome'],
            'endereco' => $inst['endereco'],
            'telefone' => $inst['telefone'],
            'usuarios' => $usuarios
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}

$conn->close();
?>