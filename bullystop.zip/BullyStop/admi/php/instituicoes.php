<?php

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}

require_once '../../php/conexao.php';

try {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id <= 0) throw new Exception('ID inválido');


    $sqlInst = "SELECT id, nome, endereco, telefone FROM instituicoes WHERE id = $id";
    $resultInst = $conn->query($sqlInst);
    if ($resultInst->num_rows === 0) throw new Exception('Instituição não encontrada');
    $inst = $resultInst->fetch_assoc();


    $sqlUsuarios = "SELECT id, nome, email, tipo_usuario, codigo_escolar, idade, data_cadastro 
                    FROM usuarios WHERE instituicao_id = $id ORDER BY nome ASC";
    $resultUsuarios = $conn->query($sqlUsuarios);
    $usuarios = [];
    while ($row = $resultUsuarios->fetch_assoc()) {
        $usuarios[] = [
            'id' => $row['id'],
            'nome' => $row['nome'],
            'email' => $row['email'],
            'tipo_usuario' => $row['tipo_usuario'],
            'codigo_escolar' => $row['codigo_escolar'],
            'idade' => $row['idade'],
            'data_cadastro' => $row['data_cadastro']
        ];
    }

    echo json_encode([
        'success' => true,
        'instituicao' => [
            'id' => $inst['id'],
            'nome' => $inst['nome'],
            'endereco' => $inst['endereco'],
            'telefone' => $inst['telefone'],
            'usuarios' => $usuarios
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}

$conn->close();
