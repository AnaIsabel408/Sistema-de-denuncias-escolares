<?php

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}

require_once '../../php/conexao.php';

$acao = isset($_GET['acao']) ? $_GET['acao'] : '';

try {
    switch ($acao) {
        case 'estatisticas':

            $sqlInst = "SELECT COUNT(*) as total FROM instituicoes";
            $resultInst = $conn->query($sqlInst);
            $totalInst = $resultInst->fetch_assoc()['total'];


            $sqlUsers = "SELECT COUNT(*) as total FROM usuarios";
            $resultUsers = $conn->query($sqlUsers);
            $totalUsers = $resultUsers->fetch_assoc()['total'];

            echo json_encode([
                'success' => true,
                'total_instituicoes' => $totalInst,
                'total_usuarios' => $totalUsers
            ]);
            break;

        case 'listar':

            $sql = "SELECT 
                        i.id,
                        i.nome,
                        i.endereco,
                        i.telefone,
                        COUNT(u.id) as total_usuarios
                    FROM instituicoes i
                    LEFT JOIN usuarios u ON i.id = u.instituicao_id
                    GROUP BY i.id, i.nome, i.endereco, i.telefone
                    ORDER BY i.nome ASC";
            
            $result = $conn->query($sql);
            $instituicoes = [];
            
            while ($row = $result->fetch_assoc()) {
                $instituicoes[] = [
                    'id' => $row['id'],
                    'nome' => $row['nome'],
                    'endereco' => $row['endereco'],
                    'telefone' => $row['telefone'],
                    'total_usuarios' => $row['total_usuarios']
                ];
            }

            echo json_encode([
                'success' => true,
                'instituicoes' => $instituicoes
            ]);
            break;

        default:
            throw new Exception('Ação inválida');
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}

$conn->close();
?>