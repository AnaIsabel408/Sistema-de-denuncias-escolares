<?php

header('Content-Type: application/json');
session_start();


if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}


require_once '../../php/conexao.php';

try {

    $sql = "SELECT DISTINCT tipo_bullying as nome 
            FROM denuncias 
            WHERE tipo_bullying IS NOT NULL AND tipo_bullying != ''
            ORDER BY tipo_bullying";
    
    $result = $conn->query($sql);
    $tipos = [];

    while ($row = $result->fetch_assoc()) {
        $tipos[] = [
            'nome' => $row['nome']
        ];
    }

    echo json_encode([
        'success' => true,
        'tipos' => $tipos
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Erro ao buscar tipos: ' . $e->getMessage()
    ]);
}

$conn->close();
?>