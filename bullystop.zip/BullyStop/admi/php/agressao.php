<?php
// Desabilitar exibição de erros HTML e forçar JSON
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}

require_once '../../php/conexao.php';

try {

    $sql = "SELECT id, nome FROM tipo_agressao ORDER BY nome ASC";
    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception('Erro ao buscar tipos: ' . $conn->error);
    }
    
    $tipos = [];
    while ($row = $result->fetch_assoc()) {
        $tipos[] = [
            'id' => $row['id'],
            'nome' => $row['nome']
        ];
    }

    echo json_encode([
        'success' => true,
        'tipos' => $tipos
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}

$conn->close();
?>