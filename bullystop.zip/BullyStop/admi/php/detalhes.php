<?php

header('Content-Type: application/json');
session_start();


if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}


require_once '../../php/conexao.php';

try {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id <= 0) throw new Exception('ID inválido');

    $sql = "
        SELECT 
            d.*,
            s.nome_status AS status,
            u.nome AS vitima_nome,
            u.email AS vitima_email,
            u.idade AS vitima_idade,
            u.codigo_escolar AS vitima_codigo,
            ta.nome AS tipo,
            i.nome AS escola_nome,
            i.endereco AS escola_endereco,
            i.telefone AS escola_telefone
        FROM denuncia d
        LEFT JOIN status_denuncia s ON d.status_id = s.id
        LEFT JOIN usuarios u ON d.usuario_id = u.id
        LEFT JOIN instituicoes i ON d.instituicao_id = i.id
        LEFT JOIN tipo_agressao ta ON d.tipo_agressao_id = ta.id
        WHERE d.id = $id
    ";

    $result = $conn->query($sql);
    if (!$result || $result->num_rows === 0) throw new Exception('Denúncia não encontrada');

    $row = $result->fetch_assoc();

    $denuncia = [
        'id' => $row['id'],
        'status' => $row['status'] ?? 'Pendente',
        'prioridade' => $row['prioridade'] ?? 'media',
        'data_ocorrido' => date('d/m/Y', strtotime($row['data_ocorrido'])),
        'data_registro' => date('d/m/Y H:i', strtotime($row['data_ocorrido'])), // usando data_ocorrido como registro
        'anonima' => $row['anonima'] == 1,
        'tipo' => $row['tipo'] ?? 'Não especificado',
        'local' => $row['local'] ?? 'Não especificado',
        'descricao' => $row['descricao'] ?? 'Sem descrição',
        'vitima' => [
            'nome' => $row['anonima'] == 1 ? 'Anônimo' : ($row['vitima_nome'] ?? 'Não informado'),
            'email' => $row['anonima'] == 1 ? 'Oculto' : ($row['vitima_email'] ?? 'Não informado'),
            'idade' => $row['anonima'] == 1 ? 'Oculta' : ($row['vitima_idade'] ?? 'Não informada'),
            'codigo_escolar' => $row['anonima'] == 1 ? 'Oculto' : ($row['vitima_codigo'] ?? 'Não informado')
        ],
        'escola' => [
            'nome' => $row['escola_nome'] ?? 'Não informado',
            'tipo' => 'Instituição de Ensino',
            'endereco' => $row['escola_endereco'] ?? 'Não informado',
            'telefone' => $row['escola_telefone'] ?? 'Não informado'
        ]
    ];

    echo json_encode([
        'success' => true,
        'denuncia' => $denuncia
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}

$conn->close();
?>
