<?php
session_start();
header('Content-Type: application/json');


if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso negado'
    ]);
    exit;
}

include '../../php/conexao.php';

try {
  
    $status  = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';
    $tipo    = isset($_GET['tipo']) ? $conn->real_escape_string($_GET['tipo']) : '';
    $periodo = isset($_GET['periodo']) ? $conn->real_escape_string($_GET['periodo']) : 'todos';
    $busca   = isset($_GET['busca']) ? $conn->real_escape_string($_GET['busca']) : '';


    $sql = "
        SELECT 
            d.id,
            ta.nome AS tipo,
            d.local AS local_ocorrencia,
            s.nome_status AS status,
            i.nome AS escola,
            IF(d.anonima = 1, 'Anônimo', u.nome) AS usuario,
            DATE_FORMAT(d.data_ocorrido, '%d/%m/%Y') AS data
        FROM denuncia d
        LEFT JOIN tipo_agressao ta ON d.tipo_agressao_id = ta.id
        LEFT JOIN status_denuncia s ON d.status_id = s.id
        LEFT JOIN instituicoes i ON d.instituicao_id = i.id
        LEFT JOIN usuarios u ON d.usuario_id = u.id
        WHERE 1=1
    ";

 
    if (!empty($status)) {
        $sql .= " AND s.nome_status = '$status'";
    }

    if (!empty($tipo)) {
        $sql .= " AND ta.nome = '$tipo'";
    }

    if (!empty($busca)) {
        $sql .= " AND (
            d.id LIKE '%$busca%' OR
            u.nome LIKE '%$busca%' OR
            i.nome LIKE '%$busca%'
        )";
    }


    switch ($periodo) {
        case 'hoje':
            $sql .= " AND DATE(d.data_ocorrido) = CURDATE()";
            break;
        case 'semana':
            $sql .= " AND YEARWEEK(d.data_ocorrido, 1) = YEARWEEK(CURDATE(), 1)";
            break;
        case 'mes':
            $sql .= " AND MONTH(d.data_ocorrido) = MONTH(CURDATE()) 
                     AND YEAR(d.data_ocorrido) = YEAR(CURDATE())";
            break;
    }

    $sql .= " ORDER BY d.data_ocorrido DESC";

    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception('Erro na query: ' . $conn->error);
    }

    $denuncias = [];
    while ($row = $result->fetch_assoc()) {
        $denuncias[] = [
            'id' => $row['id'],
            'tipo' => $row['tipo'] ?? 'Não especificado',
            'local' => $row['local_ocorrencia'] ?? 'Não especificado',
            'status' => $row['status'],
            'usuario' => $row['usuario'],
            'escola' => $row['escola'] ?? 'Não especificado',
            'data' => $row['data']
        ];
    }

 
    $totais = [
        'total' => 0,
        'novas_hoje' => 0,
        'aguardando' => 0
    ];


    $resTotal = $conn->query("SELECT COUNT(*) AS total FROM denuncia");
    if ($resTotal) {
        $totais['total'] = (int)$resTotal->fetch_assoc()['total'];
    }

    $resHoje = $conn->query("SELECT COUNT(*) AS total FROM denuncia WHERE DATE(data_ocorrido) = CURDATE()");
    if ($resHoje) {
        $totais['novas_hoje'] = (int)$resHoje->fetch_assoc()['total'];
    }

    $resPendentes = $conn->query("SELECT COUNT(*) AS total FROM denuncia WHERE status_id = 1");
    if ($resPendentes) {
        $totais['aguardando'] = (int)$resPendentes->fetch_assoc()['total'];
    }

    echo json_encode([
        'success' => true,
        'denuncias' => $denuncias,
        'totais' => $totais
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Erro: ' . $e->getMessage()
    ]);
}

$conn->close();
?>
