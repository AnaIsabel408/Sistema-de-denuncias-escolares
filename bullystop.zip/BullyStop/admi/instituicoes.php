<?php include 'php/verificar_admin.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="usuarios.css">
    <title>BullyStop - Instituições</title>
</head>
<body>
    <div class="divisor">
        <aside>
            <div>
                <h1>BullyStop</h1>
                <div class="admin-badge">PAINEL ADMINISTRATIVO</div>
            </div>
            <div class="links">
                <a href="admi.php">Início</a>
                <a href="Denuncias.php">Denúncias</a>
                <a href="instituicoes.php" class="active">usuarios</a>
            </div>
            <p><a href="../php/logout.php">Sair</a></p>
        </aside>

        <div class="page">
            <div class="page-header">
                <h1>Gerenciar Instituições e alunos</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>TOTAL DE INSTITUIÇÕES</h3>
                        <div class="stat-number">0</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>TOTAL DE USUÁRIOS</h3>
                        <div class="stat-number">0</div>
                    </div>
                </div>
            </div>

            <div class="filters-section">
                <input type="text" class="search-input" placeholder="Buscar por nome ou endereço...">
                <button class="btn btn-primary">Buscar</button>
            </div>

            <div class="instituicoes-grid">
 
            </div>
        </div>
    </div>


    <div id="modalInstituicao" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Detalhes da Instituição</h2>
                <span class="close" onclick="fecharModal()">&times;</span>
            </div>
            <div class="modal-body"></div>
            <div class="modal-actions"></div>
        </div>
    </div>

<script>

let todasInstituicoes = [];
let instituicoesFiltradas = [];


document.addEventListener('DOMContentLoaded', () => {
    carregarEstatisticas();
    carregarInstituicoes();

    document.querySelector('.search-input').addEventListener('input', aplicarFiltros);
    document.querySelector('.btn-primary').addEventListener('click', aplicarFiltros);
});

function carregarEstatisticas() {
    fetch('php/instituicoes.php?acao=estatisticas')
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = data.total_instituicoes || 0;
                document.querySelector('.stat-card:nth-child(2) .stat-number').textContent = data.total_usuarios || 0;
            }
        })
        .catch(err => console.error('Erro ao carregar estatísticas:', err));
}

function carregarInstituicoes() {
    fetch('php/instituicoes.php?acao=listar')
        .then(res => res.json())
        .then(data => {
            if(!data.success) {
                console.error(data.mensagem);
                return;
            }
            todasInstituicoes = data.instituicoes;
            instituicoesFiltradas = data.instituicoes;
            renderizarInstituicoes(instituicoesFiltradas);
        })
        .catch(err => {
            console.error('Erro ao carregar instituições:', err);
            document.querySelector('.instituicoes-grid').innerHTML =
                '<p style="text-align:center; padding:40px; color:#f44336;">Erro ao carregar instituições.</p>';
        });
}


function aplicarFiltros() {
    const termo = document.querySelector('.search-input').value.toLowerCase();

    instituicoesFiltradas = todasInstituicoes.filter(inst => {
        const nome = inst.nome?.toLowerCase() ?? '';
        const endereco = inst.endereco?.toLowerCase() ?? '';
        return termo === '' || nome.includes(termo) || endereco.includes(termo);
    });

    renderizarInstituicoes(instituicoesFiltradas);
}


function renderizarInstituicoes(lista) {
    const container = document.querySelector('.instituicoes-grid');
    container.innerHTML = '';

    if(!lista || lista.length === 0) {
        container.innerHTML = '<p style="text-align:center; padding:40px; color:#666;">Nenhuma instituição encontrada.</p>';
        return;
    }

    lista.forEach(inst => {
        const div = document.createElement('div');
        div.className = 'instituicao-card';
        div.innerHTML = `
            <div class="instituicao-header">
                <h3>${inst.nome}</h3>
                <span class="total-usuarios">${inst.total_usuarios || 0} usuário(s)</span>
            </div>
            <div class="instituicao-actions">
                <button class="btn-action btn-view" onclick="verInstituicao(${inst.id})">Ver Usuários</button>
            </div>
        `;
        container.appendChild(div);
    });
}


function verInstituicao(id) {
    fetch(`php/detalhes1.php?id=${id}`)
        .then(res => res.json())
        .then(data => {
            if(!data.success) {
                alert(data.mensagem || 'Erro ao carregar detalhes');
                return;
            }

            const inst = data.instituicao;
            const modal = document.getElementById('modalInstituicao');
            const body = modal.querySelector('.modal-body');
            const actions = modal.querySelector('.modal-actions');

            let html = `
                <p><strong>Endereço:</strong> ${inst.endereco || '-'}</p>
                <p><strong>Telefone:</strong> ${inst.telefone || '-'}</p>
                <h3>Usuários:</h3>
            `;

            if(inst.usuarios.length === 0) {
                html += '<p>Nenhum usuário cadastrado nesta instituição.</p>';
            } else {
                html += `<table style="width:100%; border-collapse:collapse;">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Email</th>
                                    <th>Tipo</th>
                                    <th>Código Escolar</th>
                                    <th>Idade</th>
                                </tr>
                            </thead>
                            <tbody>`;
                inst.usuarios.forEach(u => {
                    html += `<tr>
                        <td>${u.nome}</td>
                        <td>${u.email}</td>
                        <td>${getRoleText(u.tipo_usuario)}</td>
                        <td>${u.codigo_escolar || '-'}</td>
                        <td>${u.idade || '-'}</td>
                    </tr>`;
                });
                html += '</tbody></table>';
            }

            body.innerHTML = html;
            actions.innerHTML = '<button class="btn-cancel" onclick="fecharModal()">Fechar</button>';
            modal.style.display = 'block';
        })
        .catch(err => {
            console.error('Erro:', err);
            alert('Erro ao carregar usuários da instituição');
        });
}


function fecharModal() {
    const modal = document.getElementById('modalInstituicao');
    modal.style.display = 'none';
}


function getRoleText(tipo) {
    const map = { 'vitima':'Vítima', 'moderador':'Moderador', 'admin':'Administrador' };
    return map[tipo] || tipo;
}


window.onclick = function(event) {
    const modal = document.getElementById('modalInstituicao');
    if(event.target === modal) fecharModal();
}
</script>
</body>
</html>
