<?php include 'php/verificar_admin.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admi.css">
    <title>BullyStop - Painel Admin</title>
</head>
<body>
    <div class="divisor">
        <aside>
            <div>
                <h1>BullyStop</h1>
                <div class="admin-badge">PAINEL ADMINISTRATIVO</div>
            </div>
            <div class="links">
                <a href="admi.php" class="active">Inicio</a>
                <a href="denuncias.php">Denúncias</a>
                <a href="usuarios.php">Usuários</a>
            </div>
            <p><a href="../php/logout.php">Sair</a></p>
        </aside>
        
        <div class="page">
            <div class="page-header">
                <div class="user-info">
                    <div>
                        <div style="font-weight: 600; color: var(--cor-texto);">Administrador</div>
                        <div style="font-size: 12px; color: #666;" id="ultimoAcesso">Carregando...</div>
                    </div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>TOTAL DE DENÚNCIAS</h3>
                        <div class="stat-number" id="totalDenuncias">0</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-info">
                        <h3>CASOS PENDENTES</h3>
                        <div class="stat-number" id="casosPendentes">0</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-info">
                        <h3>CASOS RESOLVIDOS</h3>
                        <div class="stat-number" id="casosResolvidos">0</div>
                    </div>
                </div>
            </div>

            <div class="recent-complaints">
                <h2>Denúncias Recentes</h2>
                <div id="denunciasRecentes">
                    <p style="text-align:center; color:#666; padding:20px;">Carregando...</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function formatarUltimoAcesso() {
            const agora = new Date();
            const horas = String(agora.getHours()).padStart(2, '0');
            const minutos = String(agora.getMinutes()).padStart(2, '0');
            document.getElementById('ultimoAcesso').textContent = `Último acesso: Hoje, ${horas}:${minutos}`;
        }

        function getStatusClass(status) {
            const statusLower = status.toLowerCase();
            if (statusLower === 'pendente') return 'status-urgente';
            if (statusLower === 'em análise') return 'status-analisando';
            if (statusLower === 'resolvido') return 'status-resolvido';
            return 'status-pendente';
        }
        function renderizarDenunciasRecentes(denuncias) {
            const container = document.getElementById('denunciasRecentes');
            
            if (!denuncias || denuncias.length === 0) {
                container.innerHTML = '<p style="text-align:center; color:#666; padding:20px;">Nenhuma denúncia recente.</p>';
                return;
            }

            container.innerHTML = '';

            denuncias.forEach(d => {
                const div = document.createElement('div');
                div.classList.add('complaint-item');
                div.onclick = () => window.location.href = `denuncias.php?id=${d.id}`;

                div.innerHTML = `
                    <div class="complaint-info">
                        <div class="complaint-title">${d.tipo} - ${d.local}</div>
                        <div class="complaint-meta">👤 ${d.usuario} • 📍 ${d.escola}</div>
                    </div>
                    <span class="complaint-status ${getStatusClass(d.status)}">${d.status.toUpperCase()}</span>
                `;

                container.appendChild(div);
            });
        }

        function carregarDashboard() {
            fetch('php/admin.php')
                .then(res => res.json())
                .then(data => {
                    console.log('Dados recebidos:', data);

                    if (data.success) {
                        document.getElementById('totalDenuncias').textContent = data.stats.total_denuncias;
                        document.getElementById('casosPendentes').textContent = data.stats.casos_pendentes;
                        document.getElementById('casosResolvidos').textContent = data.stats.casos_resolvidos;
                        renderizarDenunciasRecentes(data.denuncias_recentes);
                    } else {
                        console.error('Erro:', data.mensagem);
                        if (data.mensagem === 'Acesso negado') {
                            alert('Acesso negado. Você precisa ser administrador.');
                            window.location.href = '../index.html';
                        }
                    }
                })
                .catch(err => {
                    console.error('Erro ao carregar dashboard:', err);
                    document.getElementById('denunciasRecentes').innerHTML = 
                        '<p style="text-align:center; color:#f44336; padding:20px;">Erro ao carregar dados.</p>';
                });
        }

 
        formatarUltimoAcesso();
        carregarDashboard();

        setInterval(carregarDashboard, 10000);
    </script>
</body>
</html>