<?php
header('Content-Type: application/json');
session_start();

try {
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "Bullystop";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }

    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if (!$email || !$senha) {
        throw new Exception("Preencha todos os campos.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Email inválido.");
    }

    $stmt = $conn->prepare("SELECT id, nome, senha, tipo_usuario FROM usuarios WHERE email=?");
    if (!$stmt) {
        throw new Exception("Erro na preparação da query: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $nome, $senha_hash, $tipo_usuario);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();

        $senha_correta = false;
 
        if (password_verify($senha, $senha_hash)) {
            $senha_correta = true;
        }

        else if ($senha === $senha_hash) {
            $senha_correta = true;
        }
        
        if ($senha_correta) {
            $_SESSION['usuario_id'] = $id;
            $_SESSION['usuario_nome'] = $nome;
            $_SESSION['tipo_usuario'] = $tipo_usuario ?? 'user'; 
            
            $redirect = ($tipo_usuario === 'admin') ? '../admi/admi.php' : '../user_paginas/index.php';
            
            echo json_encode([
                'success' => true, 
                'mensagem' => 'Login realizado com sucesso!',
                'tipo_usuario' => $tipo_usuario,
                'redirect' => $redirect
            ]);
        } else {
            echo json_encode(['success' => false, 'mensagem' => 'Senha incorreta.']);
        }
    } else {
        echo json_encode(['success' => false, 'mensagem' => 'Usuário não encontrado.']);
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Erro no login: " . $e->getMessage());
    echo json_encode(['success' => false, 'mensagem' => $e->getMessage()]);
}
?>