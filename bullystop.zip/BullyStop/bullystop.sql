-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19-Jan-2026 às 07:40
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bullystop`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `denuncia`
--

CREATE TABLE `denuncia` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `instituicao_id` int(10) UNSIGNED NOT NULL,
  `tipo_agressao_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED DEFAULT 1,
  `local` varchar(150) DEFAULT NULL,
  `data_ocorrido` date DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `anonima` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `denuncia`
--

INSERT INTO `denuncia` (`id`, `usuario_id`, `instituicao_id`, `tipo_agressao_id`, `status_id`, `local`, `data_ocorrido`, `descricao`, `anonima`) VALUES
(1, 3, 20, 3, 1, 'sala 20', '2026-01-16', 'aconteceu o que tinha que acontecer', 0),
(2, 3, 20, 5, 1, 'sei l', '2026-01-07', 'ACONTECEU', 1),
(3, 8, 14, 2, 1, 'No instagram', '2026-01-06', 'Eu fiz uma postagem sobre um dos meus hobbies, e fui maltratado nos comentários por pessoas que frequentam a mesma escola que eu.', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `instituicoes`
--

CREATE TABLE `instituicoes` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(150) NOT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `instituicoes`
--

INSERT INTO `instituicoes` (`id`, `nome`, `endereco`, `telefone`) VALUES
(11, 'Alpega International School – Luanda', 'Rua do Alpega, Talatona, Luanda', '+244 923 456 789'),
(12, 'Escola Albert Einstein – Luanda', 'Av. Comandante Valódia, Luanda', '+244 922 123 456'),
(13, 'IPDDF – Instituto Privado de Desenvolvimento de Formação – Luanda', 'Rua 17 de Setembro, Luanda', '+244 926 987 654'),
(14, 'Escola Americana de Luanda', 'Rua da Missão Americana, Luanda', '+244 923 654 321'),
(15, 'Colégio do Futuro – Luanda', 'Av. Patrice Lumumba, Luanda', '+244 922 555 666'),
(16, 'Escola Portuguesa de Luanda', 'Rua República de Portugal, Luanda', '+244 923 777 888'),
(17, 'Escola Internacional de Luanda', 'Av. Comandante Valódia, Luanda', '+244 926 111 222'),
(18, 'Colégio São José de Cluny – Luanda', 'Rua do Cluny, Maianga, Luanda', '+244 922 333 444'),
(19, 'Escola Alemã de Luanda', 'Rua da Alemanha, Talatona, Luanda', '+244 923 888 999'),
(20, 'Colégio Mateus – Luanda', 'Av. Brasil, Luanda', '+244 926 444 555'),
(21, 'Administração BullyStop', 'Sistema Administrativo', '(00) 0000-0000');

-- --------------------------------------------------------

--
-- Estrutura da tabela `status_denuncia`
--

CREATE TABLE `status_denuncia` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `status_denuncia`
--

INSERT INTO `status_denuncia` (`id`, `nome_status`) VALUES
(1, 'Pendente'),
(2, 'Em análise'),
(3, 'Resolvido'),
(4, 'Arquivado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_agressao`
--

CREATE TABLE `tipo_agressao` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tipo_agressao`
--

INSERT INTO `tipo_agressao` (`id`, `nome`) VALUES
(1, 'Bullying verbal'),
(2, 'Cyberbullying'),
(3, 'Agressão física'),
(4, 'Exclusão social'),
(5, 'Assédio psicológico');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(150) NOT NULL,
  `idade` tinyint(3) UNSIGNED NOT NULL,
  `codigo_escolar` varchar(30) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo_usuario` enum('aluno','admin') DEFAULT 'aluno',
  `instituicao_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `idade`, `codigo_escolar`, `email`, `senha`, `tipo_usuario`, `instituicao_id`) VALUES
(1, 'Ana Isabel Fernando Hossi ', 17, '5432', 'ana3@gmail.com', '$2y$10$wg46AwLELYvE51KqbW7eQOoGPds6xQadHitxPw0osict5n/5E/Th6', 'aluno', 11),
(2, 'paulinha hossi', 14, '2345', 'annecookie14@gmail.com', '$2y$10$28cXENYogucrYQVlfwfNseMMyhh5zL5XPbMHRHPW7p970yo72OW9W', 'aluno', 20),
(3, 'Alex Hossi', 12, '6543', 'alex@gmail.com', '$2y$10$0IL7drOFKowHeGJYOvbmW.uq.K9.0hjrW9wzLOTNYLlMYaBf9Hpd.', 'aluno', 20),
(5, 'Administrador', 30, 'ADMIN001', 'admin@bullystop.com', 'admin123', 'admin', 21),
(6, 'Rainando Felix', 16, '4397', 'rainando@gmail.com', '$2y$10$sY4LJh5I5w.3PXl6MA3VC.gVUBQzomuNVc9pkX4y7KtZFuUSBB0su', 'aluno', 18),
(8, 'Fernado de Assis', 15, '0987', 'fernando@gmail.com', '$2y$10$IkEUzo65dO4aFKwUzeZ0ieWtzo9E4LXEoDShlWw7InQ8MKnOPFz7K', 'aluno', 14);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `denuncia`
--
ALTER TABLE `denuncia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_denuncia_usuario` (`usuario_id`),
  ADD KEY `fk_denuncia_instituicao` (`instituicao_id`),
  ADD KEY `fk_denuncia_tipo` (`tipo_agressao_id`),
  ADD KEY `fk_denuncia_status` (`status_id`);

--
-- Índices para tabela `instituicoes`
--
ALTER TABLE `instituicoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `status_denuncia`
--
ALTER TABLE `status_denuncia`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tipo_agressao`
--
ALTER TABLE `tipo_agressao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uq_codigo_escolar` (`codigo_escolar`),
  ADD KEY `fk_usuario_instituicao` (`instituicao_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `denuncia`
--
ALTER TABLE `denuncia`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `instituicoes`
--
ALTER TABLE `instituicoes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de tabela `status_denuncia`
--
ALTER TABLE `status_denuncia`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tipo_agressao`
--
ALTER TABLE `tipo_agressao`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `denuncia`
--
ALTER TABLE `denuncia`
  ADD CONSTRAINT `fk_denuncia_instituicao` FOREIGN KEY (`instituicao_id`) REFERENCES `instituicoes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_denuncia_status` FOREIGN KEY (`status_id`) REFERENCES `status_denuncia` (`id`),
  ADD CONSTRAINT `fk_denuncia_tipo` FOREIGN KEY (`tipo_agressao_id`) REFERENCES `tipo_agressao` (`id`),
  ADD CONSTRAINT `fk_denuncia_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuario_instituicao` FOREIGN KEY (`instituicao_id`) REFERENCES `instituicoes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
