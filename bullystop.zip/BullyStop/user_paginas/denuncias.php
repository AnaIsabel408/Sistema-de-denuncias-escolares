<?php include '../php/sessao.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="denuncias.css">
<title>BullyStop</title>
</head>
<body>

<div class="divisor">
    <aside>
        <h1>BullyStop</h1>
        <div class="links">
            <a href="index.php">Início</a>
            <a href="denuncias.php" class="active">Denúncias</a>
            <a href="centro.php">Centro de ajuda</a>
        </div>
        <p><a href="../php/logout.php">Sair</a></p>
    </aside>

    <div class="page">
        <div class="page-header">
            <h1>Minhas Denúncias</h1>
            <button class="btn-nova" onclick="abrirModal()">Nova Denúncia</button>
        </div>

        <div class="filtros">
            <button class="filtro-btn ativo" onclick="filtrar('todas')">Todas</button>
            <button class="filtro-btn" onclick="filtrar('pendente')">Pendentes</button>
            <button class="filtro-btn" onclick="filtrar('em análise')">Em Análise</button>
            <button class="filtro-btn" onclick="filtrar('resolvido')">Resolvidas</button>
        </div>

        <div class="denuncias-lista" id="denunciasLista">
            <p style="text-align:center; color:#666; padding:20px;">Carregando...</p>
        </div>
    </div>
</div>

<div id="modalDenuncia" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Nova Denúncia</h2>
            <span class="close" onclick="fecharModal()">&times;</span>
        </div>
        <form id="formDenuncia" onsubmit="enviarDenuncia(event)">
            <div class="form-group">
                <label>Tipo de Bullying *</label>
                <select id="tipo_bullying" required>
                    <option value="">Carregando...</option>
                </select>
            </div>
            <div class="form-group">
                <label>Local do Incidente *</label>
                <input type="text" id="local" placeholder="Ex: Sala 204, Refeitório, Corredor..." required>
            </div>
            <div class="form-group">
                <label>Data do Incidente *</label>
                <input type="date" id="data_ocorrido" required>
            </div>
            <div class="form-group">
                <label>Descrição do Ocorrido *</label>
                <textarea id="descricao" placeholder="Descreva o ocorrido com detalhes. Sua denúncia é confidencial." required></textarea>
            </div>
            <div class="checkbox-group">
                <input type="checkbox" id="anonimo">
                <label for="anonimo" style="margin:0;font-weight:normal;">Enviar de forma anônima</label>
            </div>
            <button type="submit" class="btn-submit">Enviar Denúncia</button>
        </form>
    </div>
</div>

<script>
let todasDenuncias = [];

function abrirModal() {
    document.getElementById('modalDenuncia').style.display = 'block';
}

function fecharModal() {
    document.getElementById('modalDenuncia').style.display = 'none';
    document.getElementById('formDenuncia').reset();
}

window.addEventListener('click', (e) => {
    const modal = document.getElementById('modalDenuncia');
    if (e.target === modal) {
        fecharModal();
    }
});

function renderizarDenuncias(denuncias) {
    const container = document.getElementById('denunciasLista');
    
    if (!denuncias || denuncias.length === 0) {
        container.innerHTML = '<p style="text-align:center; color:#666; padding:20px;">Nenhuma denúncia encontrada.</p>';
        return;
    }
    
    container.innerHTML = '';

    denuncias.forEach(d => {
        const div = document.createElement('div');
        div.classList.add('denuncia-card');
        div.dataset.status = d.status.toLowerCase();

        div.innerHTML = `
            <div class="denuncia-header">
                <div class="denuncia-titulo">${d.tipo} - ${d.local}</div>
                <span class="denuncia-status status-${d.status.toLowerCase().replace(' ', '-')}">${d.status}</span>
            </div>

            <div class="denuncia-info">
                <div class="info-item">
                    <span class="info-label">DATA</span>
                    <span class="info-valor">${d.data}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">TIPO</span>
                    <span class="info-valor">${d.tipo}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">LOCAL</span>
                    <span class="info-valor">${d.local}</span>
                </div>
            </div>

            <div class="denuncia-descricao">${d.descricao}</div>
        `;
        container.appendChild(div);
    });
}


fetch('php/tipo_denuncias.php')
    .then(res => res.json())
    .then(data => {
        console.log('Tipos recebidos:', data);
        
        if (data.success) {
            const selectTipo = document.getElementById('tipo_bullying');
            selectTipo.innerHTML = '<option value="">Selecione...</option>';

            data.tipos.forEach(t => {
                const option = document.createElement('option');
                option.value = t.id;
                option.textContent = t.nome;
                selectTipo.appendChild(option);
            });
        }
    })
    .catch(err => console.error('Erro ao carregar tipos:', err));

function enviarDenuncia(e) {
    e.preventDefault();

    const tipo_agressao_id = document.getElementById('tipo_bullying').value;
    const local = document.getElementById('local').value;
    const data_ocorrido = document.getElementById('data_ocorrido').value;
    const descricao = document.getElementById('descricao').value;
    const anonima = document.getElementById('anonimo').checked ? 1 : 0;

    fetch('php/mandar_denuncia.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            tipo_agressao_id,
            local,
            data_ocorrido,
            descricao,
            anonima
        })
    })
    .then(res => res.json())
    .then(resp => {
        console.log('Resposta:', resp);
        
        if (resp.success) {
            alert('Denúncia enviada com sucesso!');
            fecharModal();
            
        } else {
            alert('Erro ao enviar denúncia: ' + resp.mensagem);
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        alert('Erro ao enviar denúncia. Verifique o console.');
    });
}
fetch('php/statusd.php')
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        todasDenuncias = data.denuncias;
                        renderizarDenuncias(todasDenuncias);
                    }
                });
function filtrar(status) {
    document.querySelectorAll('.filtro-btn')
        .forEach(btn => btn.classList.remove('ativo'));

    event.target.classList.add('ativo');

    if (status === 'todas') {
        renderizarDenuncias(todasDenuncias);
    } else {
        renderizarDenuncias(
            todasDenuncias.filter(d => d.status.toLowerCase() === status.toLowerCase())
        );
    }
}
</script>

</body>
</html>