<?php
header('Content-Type: application/json');
session_start();

try {
    if (!isset($_SESSION['usuario_id'])) {
        throw new Exception("Você precisa estar logado.");
    }

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "Bullystop";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }

    $usuario_id = $_SESSION['usuario_id'];

 
    $stmtTotal = $conn->prepare("SELECT COUNT(*) as total FROM denuncia WHERE usuario_id = ?");
    $stmtTotal->bind_param("i", $usuario_id);
    $stmtTotal->execute();
    $resultTotal = $stmtTotal->get_result();
    $totalDenuncias = $resultTotal->fetch_assoc()['total'];
    $stmtTotal->close();

    $sql = "SELECT 
                d.id,
                d.local,
                d.data_ocorrido,
                ta.nome AS tipo_agressao,
                sd.nome_status AS status
            FROM denuncia d
            LEFT JOIN tipo_agressao ta ON d.tipo_agressao_id = ta.id
            LEFT JOIN status_denuncia sd ON d.status_id = sd.id
            WHERE d.usuario_id = ?
            ORDER BY d.data_ocorrido DESC
            LIMIT 5";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $denuncias = [];
    while ($row = $result->fetch_assoc()) {
        $denuncias[] = $row;
    }

    echo json_encode([
        'success' => true,
        'totalDenuncias' => $totalDenuncias,
        'denuncias' => $denuncias
    ]);

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Erro no dashboard: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage(),
        'totalDenuncias' => 0,
        'denuncias' => []
    ]);
}
?>