<?php include '../php/sessao.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="centro.css">
    <title>BullyStop</title>

</head>
<body>
    <div class="divisor">
        <aside>
            <h1>BullyStop</h1>
            <div class="links">
                <a href="index.php">Início</a>
                <a href="denuncias.php">Denúncias</a>
                <a href="centro.php" class="active">Centro de ajuda</a>
            </div>
            <p><a href="../php/logout.php">Sair</a></p>
        </aside>
        
        <div class="page">
            <h1>Centro de Ajuda</h1>
            <p class="page-subtitle">Estamos aqui para apoiar você. Não hesite em buscar ajuda.</p>


            <div class="emergency-banner">
                <div class="emergency-icon"></div>
                <div class="emergency-content">
                    <h2>Em situação de emergência?</h2>
                    <p>Se você está em perigo imediato ou testemunhou uma situação de risco, entre em contato conosco agora mesmo.</p>
                    <div class="emergency-buttons">
                        <button class="btn-emergency">Ligar: 931-099-933</button>
                        <button class="btn-emergency">Número do WhatsApp: 931-099-933</button>
                    </div>
                </div>
            </div>
            <div class="recursos-grid">
                <div class="recurso-card">
                    <div class="recurso-header">
                        <div>
                            <h3>Linha de Apoio</h3>
                            <span class="recurso-status">Disponível agora</span>
                        </div>
                    </div>
                    <p>Fale com um especialista treinado para te ouvir e orientar. Atendimento 24 horas, 7 dias por semana.</p>
                    <p style="font-weight: bold; color: var(--cor-destaque);">931099933 (Ligação gratuita)</p>
                </div>
            <div class="materiais-section">
                <h2>Materiais Educativos</h2>
                
                <div class="material-item">
                    <div class="material-info">
                        <div class="material-text">
                            <h4>Guia: Como Identificar Bullying</h4>
                            <p>Aprenda a reconhecer os sinais de bullying e quando buscar ajuda</p>
                        </div>
                    </div>
                    <button class="btn-download" onclick="baixarArquivo('../arquivos/Como_identificar_bullying.pdf','Como_identificar_bullying.pdf')"> Download</button>
                </div>



                <div class="material-item">
                    <div class="material-info">
                        <div class="material-text">
                            <h4>O que é o bullying?</h4>
                            <p>Descubra o que é o bullying, as suas causas e muito mais</p>
                        </div>
                    </div>
                    <button class="btn-download" onclick="baixarArquivo('../arquivos/Sobre_bullying.pdf','Sobre_bullying.pdf')">Download</button>
                </div>
            </div>
        </div>
    </div>

    <script>
       function baixarArquivo(x,y) {
    const link = document.createElement('a');
    link.href = x;
    link.download = y;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
    </script>
</body>
</html>