<?php
// php/alterar_status.php
session_start();
header('Content-Type: application/json');

// Verificar se o usuário está autenticado como admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso não autorizado'
    ]);
    exit;
}

// Incluir conexão com o banco de dados
require_once '../../php/conexao.php';

// Verificar se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Método não permitido'
    ]);
    exit;
}

// Obter dados do corpo da requisição
$json = file_get_contents('php://input');
$dados = json_decode($json, true);

// Validar dados recebidos
if (!isset($dados['denuncia_id']) || !isset($dados['status_id'])) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Dados incompletos'
    ]);
    exit;
}

$denuncia_id = intval($dados['denuncia_id']);
$status_id = intval($dados['status_id']);
$observacoes = isset($dados['observacoes']) && trim($dados['observacoes']) !== '' ? trim($dados['observacoes']) : null;
$admin_id = $_SESSION['usuario_id'];

// Verificar se a denúncia existe
$sql_check_denuncia = "SELECT id, status_id FROM denuncia WHERE id = ?";
$stmt_check_denuncia = mysqli_prepare($conn, $sql_check_denuncia);
mysqli_stmt_bind_param($stmt_check_denuncia, "i", $denuncia_id);
mysqli_stmt_execute($stmt_check_denuncia);
$result_check = mysqli_stmt_get_result($stmt_check_denuncia);
$denuncia_existe = mysqli_fetch_assoc($result_check);
mysqli_stmt_close($stmt_check_denuncia);

if (!$denuncia_existe) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Denúncia não encontrada'
    ]);
    mysqli_close($conn);
    exit;
}

$status_anterior_id = $denuncia_existe['status_id'];

// Verificar se o status_id existe na tabela status_denuncia
$sql_check = "SELECT id FROM status_denuncia WHERE id = ?";
$stmt_check = mysqli_prepare($conn, $sql_check);
mysqli_stmt_bind_param($stmt_check, "i", $status_id);
mysqli_stmt_execute($stmt_check);
mysqli_stmt_store_result($stmt_check);

if (mysqli_stmt_num_rows($stmt_check) === 0) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Status inválido'
    ]);
    mysqli_stmt_close($stmt_check);
    mysqli_close($conn);
    exit;
}
mysqli_stmt_close($stmt_check);

// Iniciar transação
mysqli_begin_transaction($conn);

try {
    // Atualizar status da denúncia
    $sql = "UPDATE denuncia SET status_id = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    if (!$stmt) {
        throw new Exception('Erro ao preparar statement: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "ii", $status_id, $denuncia_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception('Erro ao executar UPDATE: ' . mysqli_stmt_error($stmt));
    }
    
    $linhas_afetadas = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
    
    // Se nenhuma linha foi afetada, pode ser porque o status já é o mesmo
    if ($linhas_afetadas === 0 && $status_anterior_id == $status_id) {
        mysqli_rollback($conn);
        echo json_encode([
            'success' => false,
            'mensagem' => 'O status selecionado já é o atual da denúncia'
        ]);
        mysqli_close($conn);
        exit;
    }
    
    // Commit da transação
    mysqli_commit($conn);
    
    echo json_encode([
        'success' => true,
        'mensagem' => 'Status alterado com sucesso',
        'denuncia_id' => $denuncia_id,
        'status_id' => $status_id,
        'status_anterior' => $status_anterior_id
    ]);
    
} catch (Exception $e) {
    // Reverter transação em caso de erro
    mysqli_rollback($conn);
    
    echo json_encode([
        'success' => false,
        'mensagem' => 'Erro ao alterar status: ' . $e->getMessage()
    ]);
}

mysqli_close($conn);
?>