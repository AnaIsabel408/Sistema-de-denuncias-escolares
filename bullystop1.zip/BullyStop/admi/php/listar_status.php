<?php
// php/listar_status.php
session_start();
header('Content-Type: application/json');

// Verificar se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Acesso não autorizado'
    ]);
    exit;
}

// Incluir conexão com o banco de dados
require_once '../../php/conexao.php';

// Buscar todos os status disponíveis
$sql = "SELECT id, nome_status FROM status_denuncia ORDER BY id";
$result = mysqli_query($conn, $sql);

if ($result) {
    $status = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $status[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'status' => $status
    ]);
} else {
    echo json_encode([
        'success' => false,
        'mensagem' => 'Erro ao carregar status: ' . mysqli_error($conn)
    ]);
}

mysqli_close($conn);
?>