<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'mensagem' => 'Acesso negado']);
    exit;
}

include '../../php/conexao.php';

try {
    // Total de denúncias
    $totalDenuncias = (int)$conn->query("SELECT COUNT(*) AS total FROM denuncia")->fetch_assoc()['total'];
    
    // Casos pendentes (status_id = 1)
    $casosPendentes = (int)$conn->query("SELECT COUNT(*) AS total FROM denuncia WHERE status_id = 1")->fetch_assoc()['total'];
    
    // Casos resolvidos - busca pelo nome do status 'resolvido' ao invés de ID fixo
    // Isso é mais flexível caso você tenha variações como "Resolvido", "Concluído", etc.
    $sqlResolvidos = "
        SELECT COUNT(*) AS total 
        FROM denuncia d
        LEFT JOIN status_denuncia s ON d.status_id = s.id
        WHERE LOWER(s.nome_status) LIKE '%resolvido%' 
           OR LOWER(s.nome_status) LIKE '%concluído%'
           OR LOWER(s.nome_status) LIKE '%finalizado%'
    ";
    $casosResolvidos = (int)$conn->query($sqlResolvidos)->fetch_assoc()['total'];

    // Denúncias recentes
    $sql = "
        SELECT 
            d.id,
            COALESCE(ta.nome, 'Não informado') AS tipo,
            COALESCE(d.local, 'Não informado') AS local,
            COALESCE(s.nome_status, 'Pendente') AS status,
            COALESCE(i.nome, 'Não informada') AS escola,
            IF(d.anonima = 1, 'Anônimo', COALESCE(u.nome,'Anônimo')) AS usuario
        FROM denuncia d
        LEFT JOIN tipo_agressao ta ON d.tipo_agressao_id = ta.id
        LEFT JOIN status_denuncia s ON d.status_id = s.id
        LEFT JOIN instituicoes i ON d.instituicao_id = i.id
        LEFT JOIN usuarios u ON d.usuario_id = u.id
        ORDER BY d.data_ocorrido DESC
        LIMIT 5
    ";

    $result = $conn->query($sql);
    if (!$result) {
        throw new Exception("Erro na query: " . $conn->error);
    }

    $denunciasRecentes = [];
    while ($row = $result->fetch_assoc()) {
        $denunciasRecentes[] = $row;
    }

    echo json_encode([
        'success' => true,
        'stats' => [
            'total_denuncias' => $totalDenuncias,
            'casos_pendentes' => $casosPendentes,
            'casos_resolvidos' => $casosResolvidos
        ],
        'denuncias_recentes' => $denunciasRecentes
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'mensagem' => 'Erro: ' . $e->getMessage()]);
}

$conn->close();
?>