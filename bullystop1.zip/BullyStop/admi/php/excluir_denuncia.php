<?php
include 'verificar_admin.php';
include '../../php/conexao.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id'])) {
    echo json_encode(['success' => false, 'mensagem' => 'ID da denúncia não fornecido']);
    exit;
}

$denuncia_id = $input['id'];

try {
    // Verificar se a denúncia existe
    $stmt = $pdo->prepare("SELECT id FROM denuncia WHERE id = ?");
    $stmt->execute([$denuncia_id]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'mensagem' => 'Denúncia não encontrada']);
        exit;
    }

    // Excluir a denúncia (admin tem permissão total)
    $stmt = $pdo->prepare("DELETE FROM denuncia WHERE id = ?");
    $stmt->execute([$denuncia_id]);

    echo json_encode(['success' => true, 'mensagem' => 'Denúncia excluída com sucesso']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'mensagem' => 'Erro ao excluir denúncia: ' . $e->getMessage()]);
}
?>