<?php include 'php/verificar_admin.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="denuncias.css">
    <title>BullyStop</title>
</head>
<body>
<div class="divisor">
    <aside>
        <div>
            <h1>BullyStop</h1>
            <div class="admin-badge">PAINEL ADMINISTRATIVO</div>
        </div>
        <div class="links">
            <a href="admi.php">Inicio</a>
            <a href="Denuncias.php" class="active">Denúncias</a>
            <a href="instituicoes.php">Usuários</a>
        </div>
        <p><a href="../php/logout.php">Sair</a></p>
    </aside>

    <div class="page">
        <div class="page-header">
            <h1>Gerenciar Denúncias</h1>
        </div>

        <div class="filters-section">
            <div class="search-bar">
                <input type="text" id="buscaInput" class="search-input" placeholder="Buscar por ID, nome, escola...">
                <button class="btn btn-primary" onclick="aplicarFiltros()">Buscar</button>
            </div>

            <div class="filters-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select id="filtroStatus" onchange="aplicarFiltros()">
                        <option value="">Todos</option>
                        <option value="pendente">Pendente</option>
                        <option value="em análise">Em Análise</option>
                        <option value="resolvido">Resolvido</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Tipo de Bullying</label>
                    <select id="filtroTipo" onchange="aplicarFiltros()">
                        <option value="">Todos</option>
                    </select>
                </div>
            </div>

            <div class="filter-tags" id="filterTags">
                <div class="filter-tag active" onclick="filtrarPorTag('todas')">Todas (0)</div>
                <div class="filter-tag" onclick="filtrarPorTag('hoje')">Novas Hoje (0)</div>
                <div class="filter-tag" onclick="filtrarPorTag('pendente')">Aguardando Ação (0)</div>
            </div>
        </div>

        <div class="denuncias-table">
            <div class="table-header">
                <h2>Lista de Denúncias</h2>
                <button class="btn btn-secondary" onclick="limparFiltros()">Limpar Filtros</button>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Denúncia</th>
                        <th>Tipo</th>
                        <th>Status</th>
                        <th>Data</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="denunciasTableBody">
                    <tr>
                        <td colspan="6" style="text-align:center; padding:40px;">Carregando denúncias...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Ver Denúncia -->
<div id="modalDenuncia" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitulo">Detalhes da Denúncia</h2>
            <span class="close" onclick="fecharModal()">&times;</span>
        </div>
        <div class="modal-body" id="modalBody"></div>
    </div>
</div>

<!-- Modal Alterar Status -->
<div id="modalStatus" class="modal">
    <div class="modal-content modal-status">
        <div class="modal-header">
            <h2>Alterar Status da Denúncia</h2>
            <span class="close" onclick="fecharModalStatus()">&times;</span>
        </div>
        <div class="modal-body">
            <form id="formStatus" onsubmit="alterarStatus(event)">
                <input type="hidden" id="denunciaId" name="denuncia_id">
                
                <div class="form-group">
                    <label for="novoStatus">Novo Status</label>
                    <select id="novoStatus" name="status_id" required>
                        <option value="">Selecione um status</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="observacoes">Observações (Opcional)</label>
                    <textarea id="observacoes" name="observacoes" rows="4" placeholder="Adicione observações sobre a alteração de status..."></textarea>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="fecharModalStatus()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script>
let denunciaAtualId = null;

document.addEventListener('DOMContentLoaded', () => {
    carregarDenuncias();
    carregarTipos();
    carregarStatus();
});

function carregarDenuncias() {
    const status = document.getElementById('filtroStatus').value;
    const tipo   = document.getElementById('filtroTipo').value;
    const busca  = document.getElementById('buscaInput').value;
    const periodo = 'todos';

    const params = new URLSearchParams({ status, tipo, busca, periodo });

    fetch(`php/denuncia.php?${params.toString()}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                alert(data.mensagem || 'Erro ao carregar denúncias');
                return;
            }
            renderizarDenuncias(data.denuncias);
            atualizarTotais(data.totais);
        })
        .catch(err => {
            console.error(err);
            alert('Erro de conexão com o servidor');
        });
}

function renderizarDenuncias(lista) {
    const tbody = document.getElementById('denunciasTableBody');
    tbody.innerHTML = '';

    if (!lista || lista.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:40px;">Nenhuma denúncia encontrada.</td></tr>`;
        return;
    }

    lista.forEach(d => {
        const statusClass = d.status.toLowerCase()
            .replace(/\s+/g, '-')
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>#${d.id}</td>
            <td>${d.local} - ${d.tipo}</td>
            <td>${d.tipo}</td>
            <td><span class="status status-${statusClass}">${d.status}</span></td>
            <td>${d.data}</td>
            <td>
                <button class="btn-action btn-view" onclick="abrirModal(${d.id})">Ver</button>
                <button class="btn-action btn-status" onclick="abrirModalStatus(${d.id}, ${d.status_id})">Status</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function atualizarTotais(totais) {
    const tags = document.getElementById('filterTags').children;
    if (tags.length >= 3) {
        tags[0].textContent = `Todas (${totais.total || 0})`;
        tags[1].textContent = `Novas Hoje (${totais.novas_hoje || 0})`;
        tags[2].textContent = `Aguardando Ação (${totais.aguardando || 0})`;
    }
}

function aplicarFiltros() { carregarDenuncias(); }

function limparFiltros() {
    document.getElementById('filtroStatus').value = '';
    document.getElementById('filtroTipo').value = '';
    document.getElementById('buscaInput').value = '';
    carregarDenuncias();
}

function filtrarPorTag(tag) {
    const tags = document.getElementById('filterTags').children;
    Array.from(tags).forEach(t => t.classList.remove('active'));
    let status = '';
    if(tag === 'hoje') tags[1].classList.add('active');
    else if(tag === 'pendente') { status='pendente'; tags[2].classList.add('active'); }
    else tags[0].classList.add('active');
    document.getElementById('filtroStatus').value = status;
    carregarDenuncias();
}

function abrirModal(id) {
    denunciaAtualId = id;
    fetch(`php/detalhes.php?id=${id}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                alert(data.mensagem || 'Erro ao carregar detalhes');
                return;
            }
            const d = data.denuncia;
            const modal = document.getElementById('modalDenuncia');
            const body = document.getElementById('modalBody');
            body.innerHTML = `
                <div class="detail-section">
                    <h3>Informações Gerais</h3>
                    <div class="detail-grid">
                        <div class="detail-item"><div class="detail-label">ID</div><div class="detail-value">#${d.id}</div></div>
                        <div class="detail-item"><div class="detail-label">Tipo</div><div class="detail-value">${d.tipo}</div></div>
                        <div class="detail-item"><div class="detail-label">Local</div><div class="detail-value">${d.local}</div></div>
                        <div class="detail-item"><div class="detail-label">Status</div><div class="detail-value">${d.status}</div></div>
                        <div class="detail-item"><div class="detail-label">Prioridade</div><div class="detail-value">${d.prioridade}</div></div>
                        <div class="detail-item"><div class="detail-label">Data do Registro</div><div class="detail-value">${d.data_registro}</div></div>
                    </div>
                </div>
                <div class="detail-section">
                    <h3>Vítima</h3>
                    <div class="detail-grid">
                        <div class="detail-item"><div class="detail-label">Nome</div><div class="detail-value">${d.vitima.nome}</div></div>
                        <div class="detail-item"><div class="detail-label">Email</div><div class="detail-value">${d.vitima.email}</div></div>
                        <div class="detail-item"><div class="detail-label">Idade</div><div class="detail-value">${d.vitima.idade}</div></div>
                        <div class="detail-item"><div class="detail-label">Código Escolar</div><div class="detail-value">${d.vitima.codigo_escolar}</div></div>
                    </div>
                </div>
                <div class="detail-section">
                    <h3>Escola</h3>
                    <div class="detail-grid">
                        <div class="detail-item"><div class="detail-label">Nome</div><div class="detail-value">${d.escola.nome}</div></div>
                        <div class="detail-item"><div class="detail-label">Endereço</div><div class="detail-value">${d.escola.endereco}</div></div>
                        <div class="detail-item"><div class="detail-label">Telefone</div><div class="detail-value">${d.escola.telefone}</div></div>
                    </div>
                </div>
                <div class="detail-section">
                    <h3>Descrição</h3>
                    <p>${d.descricao}</p>
                </div>
            `;
            modal.style.display = 'block';
        })
        .catch(err => { console.error(err); alert('Erro ao carregar detalhes da denúncia'); });
}

function fecharModal() { 
    document.getElementById('modalDenuncia').style.display = 'none';
    denunciaAtualId = null;
}



function carregarStatus() {
    fetch('php/listar_status.php')
        .then(res => res.json())
        .then(data => {
            if (!data.success) return;
            const select = document.getElementById('novoStatus');
            data.status.forEach(st => {
                const option = document.createElement('option');
                option.value = st.id;
                option.textContent = st.nome_status;
                select.appendChild(option);
            });
        })
        .catch(err => console.error('Erro ao carregar status:', err));
}

function abrirModalStatus(id, statusId) {
    document.getElementById('denunciaId').value = id;
    document.getElementById('novoStatus').value = statusId;
    document.getElementById('observacoes').value = '';
    document.getElementById('modalStatus').style.display = 'block';
}

function fecharModalStatus() {
    document.getElementById('modalStatus').style.display = 'none';
}

function alterarStatus(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const dados = {
        denuncia_id: formData.get('denuncia_id'),
        status_id: formData.get('status_id'),
        observacoes: formData.get('observacoes')
    };

    fetch('php/alterar_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Status alterado com sucesso!');
            fecharModalStatus();
            carregarDenuncias();
        } else {
            alert(data.mensagem || 'Erro ao alterar status');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Erro ao alterar status da denúncia');
    });
}

window.onclick = function(event) {
    const modalDenuncia = document.getElementById('modalDenuncia');
    const modalStatus = document.getElementById('modalStatus');
    const modalExcluir = document.getElementById('modalExcluirDenuncia');
    
    if(event.target === modalDenuncia) fecharModal();
    if(event.target === modalStatus) fecharModalStatus();
    if(event.target === modalExcluir) fecharModalExcluirDenuncia();
}

function carregarTipos() {
    fetch('php/agressao.php')
        .then(res => res.json())
        .then(data => {
            if(!data.success) return;
            const select = document.getElementById('filtroTipo');
            data.tipos.forEach(tipo => {
                const option = document.createElement('option');
                option.value = tipo.nome;
                option.textContent = tipo.nome;
                select.appendChild(option);
            });
        });
}
</script>
</body>
</html>