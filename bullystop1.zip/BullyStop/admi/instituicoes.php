<?php include 'php/verificar_admin.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="usuarios.css">
    <title>BullyStop - Instituições</title>
</head>
<body>
    <div class="divisor">
        <aside>
            <div>
                <h1>BullyStop</h1>
                <div class="admin-badge">PAINEL ADMINISTRATIVO</div>
            </div>
            <div class="links">
                <a href="admi.php">Início</a>
                <a href="Denuncias.php">Denúncias</a>
                <a href="instituicoes.php" class="active">Usuários</a>
            </div>
            <p><a href="../php/logout.php">Sair</a></p>
        </aside>

        <div class="page">
            <div class="page-header">
                <h1>Gerenciar Instituições e Alunos</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>TOTAL DE INSTITUIÇÕES</h3>
                        <div class="stat-number">0</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>TOTAL DE USUÁRIOS</h3>
                        <div class="stat-number">0</div>
                    </div>
                </div>
            </div>

            <div class="filters-section">
                <div class="search-bar">
                    <input type="text" class="search-input" placeholder="Buscar por nome ou endereço...">
                    <button class="btn btn-primary">Buscar</button>
                </div>
            </div>

            <div class="instituicoes-table">
                <div class="table-header">
                    <h2>Instituições Cadastradas</h2>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Instituição</th>
                            <th>Endereço</th>
                            <th>Telefone</th>
                            <th>Total de Usuários</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody class="instituicoes-tbody">
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px;">Carregando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="modalInstituicao" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2>Detalhes da Instituição</h2>
                <span class="close" onclick="fecharModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="instituicao-detalhes"></div>
            </div>
        </div>
    </div>

<script>
let todasInstituicoes = [];
let instituicoesFiltradas = [];

document.addEventListener('DOMContentLoaded', () => {
    carregarEstatisticas();
    carregarInstituicoes();

    document.querySelector('.search-input').addEventListener('input', aplicarFiltros);
    document.querySelector('.btn-primary').addEventListener('click', aplicarFiltros);
});

function carregarEstatisticas() {
    fetch('php/instituicoes.php?acao=estatisticas')
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = data.total_instituicoes || 0;
                document.querySelector('.stat-card:nth-child(2) .stat-number').textContent = data.total_usuarios || 0;
            }
        })
        .catch(err => console.error('Erro ao carregar estatísticas:', err));
}

function carregarInstituicoes() {
    fetch('php/instituicoes.php?acao=listar')
        .then(res => res.json())
        .then(data => {
            if(!data.success) {
                console.error(data.mensagem);
                return;
            }
            todasInstituicoes = data.instituicoes;
            instituicoesFiltradas = data.instituicoes;
            renderizarInstituicoes(instituicoesFiltradas);
        })
        .catch(err => {
            console.error('Erro ao carregar instituições:', err);
            document.querySelector('.instituicoes-tbody').innerHTML =
                '<tr><td colspan="6" style="text-align:center; padding:40px; color:#f44336;">Erro ao carregar instituições.</td></tr>';
        });
}

function aplicarFiltros() {
    const termo = document.querySelector('.search-input').value.toLowerCase();

    instituicoesFiltradas = todasInstituicoes.filter(inst => {
        const nome = inst.nome?.toLowerCase() ?? '';
        const endereco = inst.endereco?.toLowerCase() ?? '';
        return termo === '' || nome.includes(termo) || endereco.includes(termo);
    });

    renderizarInstituicoes(instituicoesFiltradas);
}

function renderizarInstituicoes(lista) {
    const tbody = document.querySelector('.instituicoes-tbody');
    tbody.innerHTML = '';

    if(!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:40px; color:#666;">Nenhuma instituição encontrada.</td></tr>';
        return;
    }

    lista.forEach(inst => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${inst.id}</td>
            <td><strong>${inst.nome}</strong></td>
            <td>${inst.endereco || '-'}</td>
            <td>${inst.telefone || '-'}</td>
            <td><span class="badge-usuarios">${inst.total_usuarios || 0}</span></td>
            <td>
                <button class="btn-action" onclick="verInstituicao(${inst.id})">Ver Usuários</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function verInstituicao(id) {
    fetch(`php/detalhes1.php?id=${id}`)
        .then(res => res.json())
        .then(data => {
            if(!data.success) {
                alert(data.mensagem || 'Erro ao carregar detalhes');
                return;
            }

            const inst = data.instituicao;
            const modal = document.getElementById('modalInstituicao');
            const detalhesDiv = modal.querySelector('.instituicao-detalhes');

            let html = `
                <div class="detail-section">
                    <h3>Informações da Instituição</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <div class="detail-label">Nome</div>
                            <div class="detail-value">${inst.nome}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Telefone</div>
                            <div class="detail-value">${inst.telefone || '-'}</div>
                        </div>
                        <div class="detail-item" style="grid-column: 1 / -1;">
                            <div class="detail-label">Endereço</div>
                            <div class="detail-value">${inst.endereco || '-'}</div>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h3>Usuários da Instituição (${inst.usuarios.length})</h3>
            `;

            if(inst.usuarios.length === 0) {
                html += '<p style="text-align: center; padding: 30px; color: #999;">Nenhum usuário cadastrado nesta instituição.</p>';
            } else {
                html += `
                    <div class="usuarios-modal-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Email</th>
                                    <th>Tipo</th>
                                    <th>Código Escolar</th>
                                    <th>Idade</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                inst.usuarios.forEach(u => {
                    const roleClass = getRoleClass(u.tipo_usuario);
                    html += `
                        <tr>
                            <td><strong>${u.nome}</strong></td>
                            <td>${u.email}</td>
                            <td><span class="role-badge ${roleClass}">${getRoleText(u.tipo_usuario)}</span></td>
                            <td>${u.codigo_escolar || '-'}</td>
                            <td>${u.idade || '-'}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                `;
            }

            html += '</div>';

            detalhesDiv.innerHTML = html;
            modal.style.display = 'block';
        })
        .catch(err => {
            console.error('Erro:', err);
            alert('Erro ao carregar usuários da instituição');
        });
}

function fecharModal() {
    const modal = document.getElementById('modalInstituicao');
    modal.style.display = 'none';
}

function getRoleText(tipo) {
    const map = { 
        'vitima': 'Vítima', 
        'moderador': 'Moderador', 
        'admin': 'Administrador' 
    };
    return map[tipo] || tipo;
}

function getRoleClass(tipo) {
    const map = { 
        'vitima': 'role-vitima', 
        'moderador': 'role-moderador', 
        'admin': 'role-admin' 
    };
    return map[tipo] || '';
}

window.onclick = function(event) {
    const modal = document.getElementById('modalInstituicao');
    if(event.target === modal) fecharModal();
}
</script>
</body>
</html>