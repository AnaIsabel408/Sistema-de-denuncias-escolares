<?php include '../php/sessao.php'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>BullyStop</title>
</head>
<body>
    <div class="divisor">
        <aside>
            <h1>BullyStop</h1>
            <div class="links">
                <a href="index.php">Início</a>
                <a href="denuncias.php">Denúncias</a>
                <a href="centro.php">Centro de ajuda</a>
            </div>
            <p><a href="../php/logout.php">Sair</a></p>
        </aside>
        
        <div class="page">
            <h1>Olá, <span id="NomeUser"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>!</h1>
            
            <div id="frase">
                <p>"Juntos somos mais fortes. Sua voz faz a diferença."</p>
            </div>
            
            <div class="container2">
                <div class="registro_denuncias">
                    <h2>Denúncias Recentes</h2>
                </div>
                
                <div class="denuncias_feitas">
                    <span id="numero_denuncias">0</span>
                    <p id="nd">Denúncias registradas</p>
                </div>
            </div>
            
            <div class="container3">
                <div class="recursos-card">
                    <h2>Recursos de Ajuda</h2>
                    <div class="recurso-item">
                        <div>
                            <strong>Linha de Apoio</strong>
                            <p style="margin: 0; font-size: 14px; color: #666;">Disponível 24/7</p>
                        </div>
                    </div>
                    <div class="recurso-item">
                        <div>
                            <strong>Material Educativo</strong>
                            <p style="margin: 0; font-size: 14px; color: #666;">Aprenda sobre prevenção</p>
                        </div>
                    </div>
                </div>
                
                <div class="recursos-card">
                    <h2>Você não está sozinho(a)</h2>
                    <div style="padding: 15px;">
                        <p style="font-size: 15px; margin-bottom: 18px; color: #666; line-height: 1.6;">
                            Estamos aqui para te apoiar em cada passo. Suas denúncias são tratadas com seriedade e confidencialidade.
                        </p>
                        <p style="font-size: 15px; margin-bottom: 18px; color: #666; line-height: 1.6;">
                            <strong style="color: var(--cor-destaque);">Você foi corajoso(a)</strong> ao buscar ajuda. Isso já é um grande passo!
                        </p>
                        <p style="font-size: 14px; margin-top: 25px; padding: 15px; background-color: #f8f9fc; border-radius: 8px; color: var(--cor-destaque); text-align: center;">
                            <strong>Estamos trabalhando para resolver suas denúncias</strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const frases = [
            "Juntos somos mais fortes. Sua voz faz a diferença.",
            "Não tenha medo de pedir ajuda. Estamos aqui por você.",
            "Cada denúncia é um passo em direção a um ambiente mais seguro.",
            "Sua coragem inspira mudanças. Continue lutando!",
            "Respeito e empatia constroem uma comunidade melhor."
        ];
        
        const fraseElemento = document.querySelector('#frase p');
        let indice = 0;
        
        setInterval(() => {
            indice = (indice + 1) % frases.length;
            fraseElemento.style.opacity = '0';
            setTimeout(() => {
                fraseElemento.textContent = frases[indice];
                fraseElemento.style.opacity = '1';
            }, 300);
        }, 5000);
        
        fraseElemento.style.transition = 'opacity 0.3s ease';
        
        // Função para normalizar status para classe CSS
        function normalizarStatusParaClasse(status) {
            return status.toLowerCase()
                .replace(/\s+/g, '-')
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, ""); // Remove acentos
        }
        
        fetch("php/denuncias.php")
            .then(response => response.text())
            .then(text => {
                const data = JSON.parse(text);
                
                if (data.success) {
                    document.getElementById("numero_denuncias").textContent = data.totalDenuncias;
                    const container = document.querySelector(".registro_denuncias");
                    container.querySelectorAll(".denuncia-item").forEach(item => item.remove());
                    
                    if (data.denuncias && data.denuncias.length > 0) {
                        data.denuncias.forEach(d => {
                            const div = document.createElement("div");
                            div.classList.add("denuncia-item");

                            // Normalizar o status para criar a classe CSS correta
                            const statusClass = 'status-' + normalizarStatusParaClasse(d.status);

                            div.innerHTML = `
                                <span>${d.tipo_agressao} - ${d.local}</span>
                                <span class="denuncia-status ${statusClass}">
                                    ${d.status}
                                </span>
                            `;
                            container.appendChild(div);
                        });
                    } else {
                        const div = document.createElement("div");
                        div.style.padding = "15px";
                        div.style.textAlign = "center";
                        div.style.color = "#666";
                        div.textContent = "Nenhuma denúncia registrada ainda.";
                        container.appendChild(div);
                    }
                }
            })
            .catch(error => console.error(error));
    </script>
</body>
</html>