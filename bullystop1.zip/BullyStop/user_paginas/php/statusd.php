<?php
header('Content-Type: application/json');
session_start();

try {
    if (!isset($_SESSION['usuario_id'])) {
        throw new Exception("Você precisa estar logado.");
    }

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "Bullystop";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }

    $usuario_id = $_SESSION['usuario_id'];


    $sqlTipos = "SELECT id, nome FROM tipo_agressao ORDER BY nome ASC";
    $resultTipos = $conn->query($sqlTipos);
    
    $tipos = [];
    if ($resultTipos) {
        while ($row = $resultTipos->fetch_assoc()) {
            $tipos[] = $row;
        }
    }


    $sql = "SELECT 
                d.id,
                d.local,
                DATE_FORMAT(d.data_ocorrido, '%d/%m/%Y') AS data,
                d.descricao,
                ta.nome AS tipo,
                sd.nome_status AS status
            FROM denuncia d
            LEFT JOIN tipo_agressao ta ON d.tipo_agressao_id = ta.id
            LEFT JOIN status_denuncia sd ON d.status_id = sd.id
            WHERE d.usuario_id = ?
            ORDER BY d.data_ocorrido DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $denuncias = [];
    while ($row = $result->fetch_assoc()) {
        $denuncias[] = $row;
    }

    echo json_encode([
        'success' => true,
        'tipos' => $tipos,
        'denuncias' => $denuncias
    ], JSON_UNESCAPED_UNICODE);

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Erro: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage(),
        'tipos' => [],
        'denuncias' => []
    ], JSON_UNESCAPED_UNICODE);
}
?>