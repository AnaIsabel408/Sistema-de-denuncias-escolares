<?php
header('Content-Type: application/json');
session_start();

try {
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "Bullystop";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }


    $sql = "SELECT id, nome FROM tipo_agressao ORDER BY nome ASC";
    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Erro na query: " . $conn->error);
    }

    $tipos = [];
    while ($row = $result->fetch_assoc()) {
        $tipos[] = $row;
    }

    echo json_encode([
        'success' => true,
        'tipos' => $tipos
    ]);

    $conn->close();

} catch (Exception $e) {
    error_log("Erro ao buscar tipos: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}
?>