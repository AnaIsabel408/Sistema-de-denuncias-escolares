<?php
session_start();
header('Content-Type: application/json');
require_once "../../php/conexao.php";

$id_usuario = $_SESSION['id_usuario'] ?? 1; 

$stmtUser = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
$stmtUser->bind_param("i", $id_usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$user = $resultUser->fetch_assoc();


$stmtTotal = $conn->prepare("SELECT COUNT(*) as total FROM denuncia WHERE id_usuario = ?");
$stmtTotal->bind_param("i", $id_usuario);
$stmtTotal->execute();
$total = $stmtTotal->get_result()->fetch_assoc()['total'];

$stmtDen = $conn->prepare("
    SELECT d.local, t.tipo, s.status
    FROM denuncia d
    JOIN tipo_agressao t ON d.tipo_id = t.id
    JOIN statusdenuncia s ON d.status_id = s.id
    WHERE d.id_usuario = ?
    ORDER BY d.data DESC
    LIMIT 5
");
$stmtDen->bind_param("i", $id_usuario);
$stmtDen->execute();
$denuncias = $stmtDen->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'nome' => $user['nome'],
    'totalDenuncias' => $total,
    'denuncias' => $denuncias
]);
?>
