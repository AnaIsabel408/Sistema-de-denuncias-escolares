<?php
header('Content-Type: application/json');
session_start();

try {

    if (!isset($_SESSION['usuario_id'])) {
        throw new Exception("Você precisa estar logado.");
    }

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "Bullystop";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }

    $json = file_get_contents('php://input');
    $dados = json_decode($json, true);

    if (!$dados) {
        throw new Exception("Dados inválidos.");
    }

    $usuario_id = $_SESSION['usuario_id'];
    $tipo_agressao_id = $dados['tipo_agressao_id'] ?? null;
    $local = trim($dados['local'] ?? '');
    $data_ocorrido = $dados['data_ocorrido'] ?? null;
    $descricao = trim($dados['descricao'] ?? '');
    $anonima = isset($dados['anonima']) ? (int)$dados['anonima'] : 0;

   
    if (!$tipo_agressao_id || !$local || !$data_ocorrido || !$descricao) {
        throw new Exception("Preencha todos os campos obrigatórios.");
    }

  
    $stmtUser = $conn->prepare("SELECT instituicao_id FROM usuarios WHERE id = ?");
    $stmtUser->bind_param("i", $usuario_id);
    $stmtUser->execute();
    $stmtUser->bind_result($instituicao_id);
    $stmtUser->fetch();
    $stmtUser->close();

    if (!$instituicao_id) {
        throw new Exception("Usuário sem instituição associada.");
    }

   
    $status_id = 1;


    $stmt = $conn->prepare("INSERT INTO denuncia (usuario_id, instituicao_id, tipo_agressao_id, status_id, local, data_ocorrido, descricao, anonima) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        throw new Exception("Erro na preparação: " . $conn->error);
    }

    $stmt->bind_param("iiiisssi", $usuario_id, $instituicao_id, $tipo_agressao_id, $status_id, $local, $data_ocorrido, $descricao, $anonima);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'mensagem' => 'Denúncia enviada com sucesso!',
            'denuncia_id' => $stmt->insert_id
        ]);
    } else {
        throw new Exception("Erro ao inserir: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Erro ao enviar denúncia: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'mensagem' => $e->getMessage()
    ]);
}
?>